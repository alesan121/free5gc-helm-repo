{{/*
Expand the name of the chart.
*/}}
{{- define "mobsim.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "mobsim.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "mobsim.labels" -}}
app.kubernetes.io/name: {{ include "mobsim.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
{{- end -}}

{{/*
Build the Multus k8s.v1.cni.cncf.io/networks annotation value for a
pod, given a dict of network->ip. Networks with an empty IP are
skipped. The output is a JSON array string.

Usage:
  {{ include "mobsim.multusAnnotation" (dict "ips" .ips "root" $) }}
*/}}
{{- define "mobsim.multusAnnotation" -}}
{{- $root := .root -}}
{{- $ips := .ips -}}
{{- $entries := list -}}
{{- range $netKey, $netName := $root.Values.multus.networks -}}
  {{- $ip := index $ips $netKey -}}
  {{- if $ip -}}
    {{- $entries = append $entries (dict "name" $netName "ips" (list $ip)) -}}
  {{- end -}}
{{- end -}}
{{- $entries | toJson -}}
{{- end -}}
