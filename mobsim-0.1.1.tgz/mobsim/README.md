# Mobsim Helm chart

Deploys the MobSim 5G RAN simulator (gNBs + UE + mobility engine) on Kubernetes,
attached to a 5G Core.
The chart parameterizes the simulation rather than hardcoding it: you say
"I want N gNBs at these positions, connected to this core" and the chart
generates the Deployments, ConfigMaps, and Services.


## Prerequisites

- An OAI 5G Core reachable from this cluster:
  - AMF exposed on an externally-routable address (NodePort or LoadBalancer)
  - The UE's IMSI/Ki/OPc already provisioned in the core's subscriber DB
- The MobSim container image (default `docker.io/frnetsoft/mobsim:latest`)
- A namespace with PodSecurity admission allowing `privileged` pods (the
  simulator uses `privileged: true` + `NET_ADMIN`)

## Quick install

Mention the Amf IP and port in the values.yaml 

```yaml
core:
  amfAddress: <oai-amf | AMF_IP>
  amfPort: 38412
```

```bash
helm install mobsim . --namespace mobsim --create-namespace
```

## Configuration

All settings live in `values.yaml`. The important sections:

### `core:` — the external 5G Core you connect to

```yaml
core:
  amfAddress: oai-amf    # where AMF is reachable from this cluster
  amfPort: 30412                       # SCTP NodePort on the core
  mcc: '001'                           # PLMN MCC the core expects
  mnc: '01'                            # PLMN MNC
  tac: 1                               # TAC the core advertises
  slice:
    sst: 1
    sd: '0xFFFFFF'
  dnn: oai                             # DNN/APN to request for PDU sessions
```

Every gNB and UE inherits these. Change one value here to retarget the whole
deployment at a different core.

### `gnb:` — how many gNBs and where they sit

```yaml
gnb:
  count: 5                             # how many gNB pods to create
  template:
    idLength: 32
    ignoreStreamIds: true
    cellPositions:                     # one entry per gNB, must have ≥ count entries
      - { lat: 48.819144, lon: 2.327528, alt: 50 }
      - { lat: 48.819144, lon: 2.347677, alt: 50 }
      # ...
```

`gnb.count=3` creates 3 gNBs using the first 3 cellPositions. `gnb.count=12`
needs at least 12 cellPositions in the list. The chart fails loudly at
`helm template` time if there aren't enough.

NCIs are auto-derived from the index (`0x000000010`, `0x000000020`, …).

### `ue:` — subscribers

```yaml
ue:
  list:
    - name: ue-0                       # used in resource names
      supi: imsi-001010000000100       # must exist in the core's subscriber DB
      key: 'fec86ba6eb707ed08905757b1bb44b8f'
      opc: 'C42449363BBAD02B66D16BC975D77CC1'
      imei: '356938035643803'
      amf: '8000'
      position:                        # MUST exactly match one cellPositions entry
        lat: 48.819144
        lon: 2.367677
```

The UE's `position.lat` and `position.lon` must equal one of the entries in
`gnb.template.cellPositions` (string-equality). The chart looks up the matching
cell index, then puts that gNB's DNS name into the UE's `gnbSearchList`. The UE
attaches to exactly that gNB.

If the position doesn't match any cell, `helm template` fails with an error
listing the available coordinates so you can fix it.

### `engine:` — the mobility / SimEngine HTTP API

```yaml
engine:
  name: eng-0
  service:
    type: NodePort                    
    port: 8080                        
    nodePort: 30808                  
```

The engine's HTTP API is reachable from outside the cluster:

```bash
curl -X POST http://$(mobsim_node_ip):30808/geolocation \
     -H 'Content-Type: application/json' \
     -d '{"ueName":"imsi-001010000000100", "lat": 48.81944, "lon": 2.367677}'
```
